This directory contains the ImageMagick messaging subsystem.  For now
the only locale supported is C.  We intend on adding additional locales
in the near future.

Until this effort is complete, perhaps around February of 2003, please
do not attempt any translations of the messages in C.mgk.
